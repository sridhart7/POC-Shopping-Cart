import { NgModule } from '@angular/core';
import { ModelModule } from '../JSONData/model.module';
import { StoreComponent } from './store.component';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CartSummaryComponent } from '../cart-summary/cart-summary.component';
import { CartDetailsComponent } from '../cart-details/cart-details.component';
import { CheckoutComponent } from '../checkout/checkout.component';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    StoreComponent, CartSummaryComponent,
    CartDetailsComponent, CheckoutComponent
  ],
  imports: [
    BrowserModule,
    ModelModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule
  ],
  exports: [
    StoreComponent, CartDetailsComponent, CheckoutComponent
  ]
})
export class StoreModule { }

