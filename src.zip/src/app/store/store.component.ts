import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from '../JSONData/product.model';
// import { Product } from '../JSONData/product.model';
import { ProductRepository } from './../JSONData/product.repository';
import { Cart } from './cart.model';


@Component({
  selector: 'store',
  templateUrl: './store.component.html',
  styleUrls: ['./store.component.scss']
})
export class StoreComponent implements OnInit {

   public selectedCategory: any = null;
   public productsPerPage = 4;
   public selectedPage = 1;
  // selectedPerPage: number | undefined;
  // selectedPerPage: number | undefined;
  //  selectedPerPage: any = Number;

   

  constructor(private repository: ProductRepository, private cart: Cart, private router: Router) { }

  ngOnInit() {
  }

  get products(): Product[]{
    let pageIndex = (this.selectedPage - 1) * this.productsPerPage;
    return this.repository.getProducts(this.selectedCategory)
    .slice(pageIndex, pageIndex + this.productsPerPage)

  }

  get categories(): string[]{
    return this.repository.getCategories();
  }  

  changeCategory ( newCategory? : string){
    this.selectedCategory = newCategory;
  }

  changePage(newPage: number){
    this.selectedPage = newPage;
  }

  changePageSize(newSize: Number){
    this.productsPerPage = Number (newSize);
    this.changeCategory()
  }

  get pageNumbers(): Number []{
    return Array(Math.ceil(this.repository
      .getProducts(this.selectedCategory).length  / this.productsPerPage))
      .fill(1).map((x,i)=> i+1);
  }
  
  addProductToCart(Product: Product){
    this.cart.addLine(Product)
    this.router.navigateByUrl('/cart');
  }
  

}
