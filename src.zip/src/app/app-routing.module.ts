import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';
import { CartDetailsComponent } from './cart-details/cart-details.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { StoreGuard } from './store.guard';
import { StoreComponent } from './store/store.component';
import { StoreModule } from './store/store.module';

const routes: Routes = [];

@NgModule({
  imports: [BrowserModule, StoreModule, 
    RouterModule.forRoot([
        {path: "store", component:StoreComponent, canActivate: [StoreGuard]},
        {path: "cart", component:CartDetailsComponent, canActivate: [StoreGuard]},
        {path: "checkout", component:CheckoutComponent, canActivate: [StoreGuard]},
        {path: "**", redirectTo: "/store"}
      ])],
      providers: [StoreGuard],
  exports: [RouterModule]
})
export class AppRoutingModule { }
