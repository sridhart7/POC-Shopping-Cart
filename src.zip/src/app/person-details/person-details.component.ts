import { Component, OnInit } from '@angular/core';
import { PersonServiceService } from '../person-service.service';

@Component({
  selector: 'app-person-details',
  templateUrl: './person-details.component.html',
  styleUrls: ['./person-details.component.scss']
})
export class PersonDetailsComponent implements OnInit {

  constructor(private _personService: PersonServiceService) { }

  ngOnInit() {
    this.personsData = this._personService.getData();
  }

    // Angular Services
  //person details
  personsData : any = [];

}

export class Engine {

}

export class Tires {
  
}

export class Car {
  enginex;
  tireabc;
  constructor(){
    this.enginex = new Engine();
    this.tireabc = new Tires();
  }
}


export class Car2 {
  enginex;
  tireabc;
  constructor(engine: any, tire: any){
    this.enginex = engine;
    this.tireabc = tire;
  }
}
