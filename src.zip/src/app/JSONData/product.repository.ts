import { Injectable } from '@angular/core';
import{ Product } from './product.model';
import { StaticDatasource } from './static.dataSource';



@Injectable()
export class ProductRepository{
     private products : Product[] = [];
     private categories: string[] = [];

    constructor(private dataSource: StaticDatasource){
        dataSource.getProducts().subscribe(data => {
            this.products = data;
            this.categories = data.map( p => p.category)
            .filter((c, index, array) => array.indexOf(c)==index).sort();
        });
 
    }

    getProducts(category : string) : Product []{
        return this.products
        .filter(p => category == null || category == p.category)
        // .filter((p: { category: string; }) => category || category == p.category);
    }

    getProduct(id: number): Product | undefined {
        // return this.products.find((p: { id: number; }) => p.id == id);
        return this.products.find(p => p.id == id );
    }

    getCategories() : string[]{
        return this.categories;
    }
   
}