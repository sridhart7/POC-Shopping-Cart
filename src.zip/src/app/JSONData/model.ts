export class model {
    user;
    items: any;

    constructor(){
        this.user = "Sridhar";
        this.items = [
            {action: "Buy flowers", done: false},
            {action: "Get Shoes", done: false},
            {action: "Collect tickets", done: true},
            {action: "Do Workout", done: false}]
    }
}

export class TodoItem{

    action;
    done;

    constructor(action: any, done: any){
        this.action = action;
        this.done = done;
    }
}
