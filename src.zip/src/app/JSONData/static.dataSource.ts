import { Injectable } from "@angular/core";
import { Product } from './product.model';
import  {from, Observable } from 'rxjs';
import { Order } from './order.model';

@Injectable()
export class StaticDatasource {
    private products: Product[] = [
        new Product(1, "Shoe", "category 1", "Sneaker Shoe (Category 1)", 100),
        new Product(2, "T-Shirt", "category 1", "Red color (Category 1)", 80),
        new Product(3, "Trial Shoe", "category 1", "Sports Shoe (Category 1)", 99),
        new Product(4, "Cooler", "category 1", "Black (Category 1)", 89),
        new Product(5, "Graphic T-Shirt", "category 1", "Design (Category 1)", 110),
        new Product(6, "Pen", "category 1", "Sneaker Shoe (Category 1)", 220),
        new Product(7, "Perfume", "category 2", "AXE (Category 2)",300),
        new Product(8, "Flowers", "category 2", "Jasmine (Category 2)", 280),
        new Product(9, "Note", "category 2", "Long Size (Category 2)", 276),
        new Product(10, "Book", "category 2", "Novel (Category 2)", 500),
        new Product(11, "Shampoo", "category 3", "High Quality (Category 3)", 20),
    ];

    getProducts() : Observable<Product[]>{
        return from([this.products]);
    }

    saveOrder (order : Order) : Observable<Order>{
        console.log(JSON.stringify(Order));
        return from([order]);
    }
}