import { NgModule } from '@angular/core';
import { Cart } from '../store/cart.model';
import { Order } from './order.model';
import { OrderRepository } from './order.repository';
import { ProductRepository } from './product.repository';
import { StaticDatasource } from './static.dataSource';

@NgModule({
    providers: [ProductRepository, StaticDatasource, Cart, Order, OrderRepository]
})

export class ModelModule {

}