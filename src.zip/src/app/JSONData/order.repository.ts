import { Injectable } from "@angular/core";
import { Observable } from 'rxjs';
import { Order } from './order.model';
import { StaticDatasource } from './static.dataSource';

@Injectable()
export class OrderRepository {
private order: Order[] = [];

constructor(private dataSource: StaticDatasource){

}

// Order which will get product from this DataSource
getOrders() : Order[]{
    return this.order;
}

saveOrder (order : Order) : Observable<Order>{
    console.log(JSON.stringify(Order));
    return this.dataSource.saveOrder(order)
}
}