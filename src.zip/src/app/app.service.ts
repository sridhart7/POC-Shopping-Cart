import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { IPerson } from './persons';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AppService {

  constructor(private http : HttpClient) { }   
   
  private person : string = "/app/JSONData/person.json";

  getData() : Observable <IPerson[]>{
    
      return this.http.get<IPerson[]>(this.person);

  }
    

}