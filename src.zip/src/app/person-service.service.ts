import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PersonServiceService {

  getData (){
    return  [
    {id: 1, name: "Sridhar", age: 30, gender: "male"},
    {id: 2, name: "Ram", age: 40, gender: "male"},
    {id: 3, name: "Jancy", age: 20, gender: "female"},
    {id: 4, name: "Harsha", age: 25, gender: "female"},
    {id: 5, name: "Heath", age: 28, gender: "male"}
    ];
  }


  constructor() { 
   
  }
}
