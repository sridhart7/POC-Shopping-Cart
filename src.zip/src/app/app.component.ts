import { Component, OnInit, ElementRef, ViewChild, OnChanges, SimpleChanges } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
// import { AppService } from "./app.service";
import { model, TodoItem } from './JSONData/model'
import { PersonServiceService } from './person-service.service';


@Component({
  selector: 'app-root',
  // templateUrl: './app.component.html',
  template: "<router-outlet></router-outlet>",
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  @ViewChild('customInput') customInput!: ElementRef;

  constructor(private reactiveform: FormBuilder, private _personService: PersonServiceService){
    
  }


  ngOnInit() {
    this.personsData = this._personService.getData();
      // this.customInput.nativeElement.value = 'Cars'
      //observable get data from http
      // this._appService.getData().subscribe (data => this.persons = data);
  }
 
  title = 'Angular concepts';
  
  // Two way binding code here
  count: number = 0;
  clearCount() {
  this.count = 0;
  }

  // Class binding
  myClass = 'FR'
  
  // Event binding
  hide: boolean = true;
  show(){
    this.hide = !this.hide; 
  }

  people: any[] = [
    {
      "name": "Concord"
    },
    {
      "name": "Sridhar"
    },
    {
      "name": "7708537874"
    },
    {
      "name": "Chennai"
    }
  ];

  // Reactive form
  profileForm = this.reactiveform.group({
    firstName: ['', Validators.required],
    lastName: [''],
    address: this.reactiveform.group({
      street: [''],
      city: [''],
      state: [''],
      zip: ['']
    }),
  });

  onSubmit(){
    console.warn(this.profileForm.value);
  }

  // Display the list and update the status
  model = new model();

  getName(){
    return this.model.user;
  }

  getToDoItems(){
    return this.model.items;
  }

  addItem(newTask: string){
    if(newTask != ''){
      this.model.items.push(new TodoItem ( newTask, false));
    }
  }


  // Angular Services
  //person details
  // personsData = [];
   personsData : any = [];


 

}
